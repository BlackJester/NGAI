#define native

const int null = 0;

struct fixed
{
	float f;
};

struct order
{
	int orderID;
};

struct abilcmd
{
	int cmdID;
};

typedef int point;

struct region
{
	point pos;
	int radius;
};

struct unit
{
	int u;
};

class string
{
	string (const char* );
	public:
		string& operator+(const char* array);
		string& operator+(string str);
		string& operator+(string* str);
		string& operator+(text* str);
		string& operator+(text str);
		string& operator+(char* x, string str);
};

class text
{
	public:
		text& operator+(const char* array);
		text& operator+(string str);
		text& operator+(string* str);
		text& operator+(text str);
		text& operator+(text* str);
		text& operator+(text& str);
};

text StringToText (char* x);
text StringToText (string x);
void TriggerDebugOutput (int type, string inText, bool includeGameUI);
void TriggerDebugOutput (int type, text inText, bool includeGameUI);

struct wave
{
	int units;
};

struct bool
{
	int true_or_false;
};

struct unitgroup
{
	unit units;
};

/***
 * Not sure about that
 */
struct marker
{
	point position;
};

/***
 * Nochmal nachlesen .. ka was das war
 */
struct wavetarget
{
	point target1;
	unit target2;
};

/***
 * Auch kp was das war
 */
struct waveinfo
{
	int waveID;
};

struct playergroup
{
	int playerArray;
};

/***
 * xD ka xD
 */
struct aifilter
{
	int x;
};

/**
 * kann units rausfiltern
 */
struct unitfilter
{
	int x;
};

/**
 * added to hide errors
 * more information needed
 */
struct trigger{
	int trigger;
};

/**
 * added to hide errors
 * more information needed
 */
struct unitref{
	int unitref;
};
